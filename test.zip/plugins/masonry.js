import Vue from 'vue'
import VueMasonry from 'vue-masonry-css'

Vue.use(VueMasonry);