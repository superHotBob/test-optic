import Vue from 'vue'
import VueCookie from 'vue-cookie'

Vue.use(VueCookie);