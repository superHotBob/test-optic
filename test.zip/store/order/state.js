export default () => ({
    order: {},
    locations: false,
    sessid:false,
    locationList: {},
    locationShow: false,
    endpoint: {
        order:'/api/v1/order/',
        location:'/api/v1/locations/'
    },
})