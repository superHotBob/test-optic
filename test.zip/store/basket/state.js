export default () => ({
  basket: [],
  endpoint: '/api/v1/basket/',
  recalculate: {
    'basketAction': 'recalculateAjax',
    'via_ajax': 'Y'
  }
})