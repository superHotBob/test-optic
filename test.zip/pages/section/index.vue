<template>
    <div>
        <nuxt-child></nuxt-child> 
    </div>
</template>

<script>
export default {
    
}
</script>
